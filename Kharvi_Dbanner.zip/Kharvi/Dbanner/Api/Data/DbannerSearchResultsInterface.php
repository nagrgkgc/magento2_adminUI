<?php

namespace Kharvi\Dbanner\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

interface DbannerSearchResultsInterface extends SearchResultsInterface
{

    /**
     * Get dbanners list
     *
     * @return \Kharvi\Dbanner\Api\Data\DbannerInterface[]
     */
    public function getItems();

    /**
     * Set dbanners list
     *
     * @param \Kharvi\Dbanner\Api\Data\DbannerInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
