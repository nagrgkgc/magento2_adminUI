<?php
namespace Kharvi\Dbanner\Controller\Adminhtml\Dbanner;

use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Backend\App\Action;

class Save extends \Magento\Backend\App\Action implements HttpPostActionInterface
{
    const ADMIN_RESOURCE = 'Kharvi_Dbanner::dbanner';

    protected $resultPageFactory;
    protected $dbannerFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Kharvi\Dbanner\Model\DbannerFactory $dbannerFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->dbannerFactory = $dbannerFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();

        if($data)
        {
            try{
                $id = $data['id'];

                $dbanner = $this->dbannerFactory->create()->load($id);

                $data = array_filter($data, function($value) {return $value !== ''; });

                $dbanner->setData($data);
                $dbanner->save();
                $this->messageManager->addSuccess(__('Successfully saved the item.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                return $resultRedirect->setPath('*/*/');
            }
            catch(\Exception $d)
            {
                $this->messageManager->addError($e->getMessage());
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData($data);
                return $resultRedirect->setPath('*/*/edit', ['id' => $dbanner->getId()]);
            }
        }

        return $resultRedirect->setPath('*/*/');
    }
}
