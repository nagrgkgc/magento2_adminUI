require(["jquery"], function($){
    $(document).ready(function() {
        //write your code here
        
    });
});