<?php
namespace Kharvi\Dbanner\Setup;

class InstallSchema implements \Magento\Framework\Setup\InstallSchemaInterface
{
    public function install(\Magento\Framework\Setup\SchemaSetupInterface $setup, \Magento\Framework\Setup\ModuleContextInterface $context)
	{
        $installer = $setup;
        $conn = $setup->getConnection();
        $tableName = $setup->getTable('kharvi_dbanner');
        if($conn->isTableExists($tableName) != true){
            $table = $conn->newTable($tableName)
            ->addColumn(
                'id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity'=>true,'unsigned'=>true,'nullable'=>false,'primary'=>true],
                'Banner ID'
            )
            ->addColumn(
                'name',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['nullable'=>false,'default'=>''],
                'Banner Name'
            )
            ->addColumn(
                'image_url',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                '2M',
                ['nullbale'=>false,'default'=>'']
            )
            ->addColumn(
				'page_url_key',
				\Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
				255,
				[],
				'Page URL Key/ID'
			)
            ->addColumn(
				'status',
				\Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
				1,
				[],
				'Banner Status'
			)
            ->addColumn(
				'created_at',
				\Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
				null,
				['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT],
				'Created At'
			)->addColumn(
				'updated_at',
				\Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
				null,
				['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT_UPDATE],
				'Updated At'
			)
            ->setOption('charset','utf8');
            $conn->createTable($table);
            
            $installer->getConnection()->addIndex(
				$installer->getTable('kharvi_dbanner'),
				$setup->getIdxName(
					$installer->getTable('kharvi_dbanner'),
					['name', 'image_url', 'page_url_key'],
					\Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
				),
				['name', 'image_url', 'page_url_key'],
				\Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
			);
        }
        $setup->endSetup();
    }
}