<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * Nagaraja Kharvi (nagrgk@gmail.com)
 */

namespace Kharvi\Dbanner\Helper;

use Magento\Framework\UrlInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    protected $_catalogHelper;
    protected $_storeManager;
    protected $_registry;
    protected $_catalogSearchData;
    protected $_categoryRepository;
    protected $_escaper;
    protected $_urlBuilder;
    protected $_request;
    protected $_scopeConfig;
    protected $_currency;
    
    public $final_url_data = array();
    public $_filtersList = array();
    
    public function __construct(
        \Magento\Framework\Registry $registry,
        \Magento\Catalog\Helper\Data $catalogHelper,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\CatalogSearch\Helper\Data $catalogSearchData,
        \Magento\Catalog\Model\CategoryRepository $categoryRepository,
        \Magento\Framework\Escaper $_escaper,
        UrlInterface $urlBuilder,
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory $productAttributeCollectionFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Directory\Model\Currency $currency
    ){
        $this->_registry = $registry;
        $this->_catalogHelper = $catalogHelper;
        $this->_storeManager = $storeManager;
        $this->_catalogSearchData = $catalogSearchData;
        $this->_categoryRepository = $categoryRepository;
        $this->_escaper=$_escaper;
        $this->_urlBuilder = $urlBuilder;
        $this->_request = $request;
        $this->productAttributeCollectionFactory = $productAttributeCollectionFactory;
        $this->_scopeConfig = $scopeConfig;
        $this->_currency = $currency; 
    }
    
    /* get category by id */
    public function getCategory($categoryId){
        return $this->_categoryRepository->get($categoryId, $this->_storeManager->getStore()->getId());
    }
       
    /* get website id */
    public function getWebsiteId(){
        $wid = $this->_storeManager->getStore()->getWebsiteId();
        $widd = '_0_' . $wid;
        
        return $widd;
    }
}