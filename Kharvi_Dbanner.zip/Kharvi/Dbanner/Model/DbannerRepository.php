<?php

namespace Kharvi\Dbanner\Model;

use Kharvi\Dbanner\Api\Data\DbannerInterface;
use Kharvi\Dbanner\Api\Data\DbannerSearchResultsInterfaceFactory;
use Kharvi\Dbanner\Api\DbannerRepositoryInterface;
use Kharvi\Dbanner\Model\ResourceModel\Dbanner as ResourceDbanner;
use Kharvi\Dbanner\Model\ResourceModel\Dbanner\CollectionFactory as DbannerCollectionFactory;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;

class DbannerRepository implements DbannerRepositoryInterface
{

    /**
     * @var ResourceDbanner
     */
    protected $resource;

    /**
     * @var DbannerFactory
     */
    protected $dbannerFactory;

    /**
     * @var DbannerCollectionFactory
     */
    protected $dbannerCollectionFactory;

    /**
     * @var DbannerSearchResultsInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    /**
     * @var DbannerInterface[]
     */
    protected $instances = [];
    
    /**
     * @param ResourceDbanner $resource
     * @param \Kharvi\Dbanner\Model\DbannerFactory $dbannerFactory
     * @param DbannerCollectionFactory $dbannerCollectionFactory
     * @param DbannerSearchResultsInterfaceFactory $searchResultsFactory
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
            ResourceDbanner $resource, 
            DbannerFactory $dbannerFactory, 
            DbannerCollectionFactory $dbannerCollectionFactory, 
            DbannerSearchResultsInterfaceFactory $searchResultsFactory, 
            CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->dbannerFactory = $dbannerFactory;
        $this->dbannerCollectionFactory = $dbannerCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * @param DbannerInterface $dbanner
     * @return DbannerInterface
     * @throws CouldNotSaveException
     */
    public function save(DbannerInterface $dbanner)
    {
        try {
            $this->resource->save($dbanner);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }
        unset($this->instances[$dbanner->getId()]);
        return $dbanner;
    }

    /**
     * @param int $dbannerId
     * @return DbannerInterface
     * @throws NoSuchEntityException
     */
    public function getById($id)
    {
        if (!isset($this->instances[$id])) {
            $dbanner = $this->dbannerFactory->create();
            $this->resource->load($dbanner, $id);
            if (!$dbanner->getId()) {
                throw new NoSuchEntityException(__('Dbanner with id "%1" does not exist.', $id));
            }
            $this->instances[$id] = $dbanner;
        }

        return $this->instances[$id];
    }

    /**
     * @param SearchCriteriaInterface $searchCriteria
     * @return DbannerSearchResultsInterface
     */
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
        /** @var \Kharvi\Dbanner\Model\ResourceModel\Dbanner\Collection $collection */
        $collection = $this->dbannerCollectionFactory->create();

        $this->collectionProcessor->process($searchCriteria, $collection);

        /** @var \Kharvi\Dbanner\Api\Data\DbannerSearchResultsInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setItems($collection->getItems());
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * @param DbannerInterface $dbanner
     * @return bool true on success
     * @throws CouldNotDeleteException
     */
    public function delete(DbannerInterface $dbanner)
    {
        try {
            $id = $dbanner->getId();
            $this->resource->delete($dbanner);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }
        unset($this->instances[$id]);
        return true;
    }

    /**
     * @param int $dbannerId
     * @return bool true on success
     */
    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }

}
